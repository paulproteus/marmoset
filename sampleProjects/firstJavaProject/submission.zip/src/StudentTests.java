import junit.framework.TestCase;

/**
 * 
 * This class holds tests written by students.
 * 
 */
public class StudentTests extends TestCase {

    public void testNothing() {
        // this doesn't test anything, but we need to have
        // a test method or the test class will fail since it
        // doesn't have any test methods
    }
}
